## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  echo = TRUE,
  eval = TRUE,
  collapse = TRUE,
  fig.width = 6)

## ----warning=FALSE, message=FALSE, echo=TRUE----------------------------------
library(APTSCausalInference)
# required for data management and plots
library(data.table)
library(dplyr)
library(ggplot2)

# required for analysis
library(AIPW)
library(cobalt)
library(ipw)
library(sandwich)
library(stdReg)
library(SuperLearner)
library(survey)

## ----load data, echo=TRUE-----------------------------------------------------
# data(bcrot)
load("../data/bcrot.RData")

